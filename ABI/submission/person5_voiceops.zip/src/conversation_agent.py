"""Step 3 Multi-turn Conversational Agent for PERSON 5 with Speech Normalization."""
import datetime
import re
from typing import Dict, Any, List, Optional
from .knowledge_base import KnowledgeBase, REFERENCE_DATE
from .retriever import MultilingualVoiceRetriever
from .tools_adapter import ToolsAdapter
from .llm_adapter import LLMAdapter
from .rag_agent import RAGAgent
from .speech_normalizer import SpeechNormalizer


class ConversationSession:
    def __init__(self, conversation_id: str):
        self.conversation_id = conversation_id
        self.order_id: Optional[str] = None
        self.verified: bool = False
        self.verification_pending: bool = False
        self.verification_attempts: int = 0
        self.order_data: Optional[Dict[str, Any]] = None
        self.history: List[Dict[str, str]] = []
        self.ticket_created: bool = False
        self.ticket_id: Optional[str] = None


class ConversationAgent:
    def __init__(self, kb: KnowledgeBase, tools: ToolsAdapter, retriever: MultilingualVoiceRetriever = None, llm: LLMAdapter = None):
        self.kb = kb
        self.tools = tools
        self.retriever = retriever or MultilingualVoiceRetriever(kb)
        self.llm = llm or LLMAdapter()
        self.sessions: Dict[str, ConversationSession] = {}

    def get_session(self, conv_id: str) -> ConversationSession:
        if conv_id not in self.sessions:
            self.sessions[conv_id] = ConversationSession(conv_id)
        return self.sessions[conv_id]

    def reset_session(self, conv_id: str):
        self.sessions[conv_id] = ConversationSession(conv_id)

    def process_turn(self, conv_id: str, message: str, explicit_order_id: Optional[str] = None) -> Dict[str, Any]:
        session = self.get_session(conv_id)
        session.history.append({'role': 'customer', 'text': message})
        msg_clean = message.strip()
        msg_lower = msg_clean.lower()

        tool_calls_made = []
        gold_evidence = []
        decision = "answer"

        found_order_id = explicit_order_id
        if not found_order_id:
            m_oid = re.search(r'\b(\d{4}\s*\d{4})\b', msg_clean) or re.search(r'\b(\d{8})\b', msg_clean)
            if m_oid:
                found_order_id = m_oid.group(1).replace(' ', '')

        if found_order_id and not session.order_id:
            session.order_id = found_order_id

        # Turn 1
        if not session.order_id and not session.verified:
            decision = "clarify"
            gold_evidence.append("STY-1")
            reply = "Hello! I am ZentroMart's AI customer support assistant (एआई सहायक). Could you please state your 8-digit order number?"
            session.history.append({'role': 'assistant', 'text': reply})
            return {'decision': decision, 'response': reply, 'spoken_response': SpeechNormalizer.normalize_for_tts(reply), 'tool_calls': tool_calls_made, 'evidence': gold_evidence, 'verified': session.verified}

        # Verification turn 1
        if session.order_id and not session.verified and not session.verification_pending:
            session.verification_pending = True
            tool_calls_made.append(f"lookup_order(order_id={session.order_id})")
            self.tools.lookup(session.order_id)
            decision = "clarify"
            gold_evidence.append("IDV-2")
            spoken_oid = SpeechNormalizer.format_order_id_for_speech(session.order_id)
            reply = f"Thank you for sharing order {session.order_id}. To verify your identity, please provide the last 4 digits of your registered phone number or your 6-digit delivery pincode (आख़िरी चार अंक या पिनकोड)."
            session.history.append({'role': 'assistant', 'text': reply})
            return {'decision': decision, 'response': reply, 'spoken_response': SpeechNormalizer.normalize_for_tts(reply), 'tool_calls': tool_calls_made, 'evidence': gold_evidence, 'verified': session.verified}

        # Verification turn 2
        if session.order_id and not session.verified and session.verification_pending:
            m_proof = re.search(r'\b(\d{4})\b', msg_clean) or re.search(r'\b(\d{6})\b', msg_clean)
            if m_proof:
                proof = m_proof.group(1)
                session.verification_attempts += 1
                tool_calls_made.append(f"lookup_order(order_id={session.order_id}, verification_value={proof})")
                res = self.tools.lookup(session.order_id, verification_value=proof)

                if res.get('verified'):
                    session.verified = True
                    session.verification_pending = False
                    session.order_data = res
                    decision = "answer"
                    gold_evidence.append("IDV-2")
                    name = res.get('customer_first_name', 'Customer')
                    reply = f"Thank you, {name}! Your identity is verified. How can I assist you with order {session.order_id}?"
                    session.history.append({'role': 'assistant', 'text': reply})
                    return {'decision': decision, 'response': reply, 'spoken_response': SpeechNormalizer.normalize_for_tts(reply), 'tool_calls': tool_calls_made, 'evidence': gold_evidence, 'verified': True}
                else:
                    gold_evidence.append("IDV-3")
                    if session.verification_attempts < 2:
                        decision = "clarify"
                        reply = "Verification did not match. Please re-check and share the last 4 digits of your phone or delivery pincode."
                    else:
                        decision = "refuse"
                        reply = "Verification failed after two attempts. To protect your security, I cannot share order details. Please contact customer care from your registered phone."
                    session.history.append({'role': 'assistant', 'text': reply})
                    return {'decision': decision, 'response': reply, 'spoken_response': SpeechNormalizer.normalize_for_tts(reply), 'tool_calls': tool_calls_made, 'evidence': gold_evidence, 'verified': False}

        # Verified queries
        if session.verified and session.order_data:
            order = session.order_data
            items = order.get('items', [])
            is_plus = order.get('is_plus', False)
            total_inr = order.get('total_inr', 0)
            delivery_date_str = order.get('delivery_date')
            order_date_str = order.get('order_date')
            payment_method = str(order.get('payment_method', '')).lower()

            is_damage = any(w in msg_lower for w in ['damage', 'defect', 'damaged', 'broken', 'kharab'])
            is_high_val = total_inr > 10000 or any(it.get('price_inr', 0) > 10000 for it in items)

            if is_damage and is_high_val:
                decision = "escalate"
                gold_evidence.extend(["DWM-3", "ESC-1", "ESC-4"])
                t_res = self.tools.ticket(
                    summary=f"Damage reported on order {session.order_id} (> ₹10,000 threshold). Priority Resolution human handover.",
                    order_id=session.order_id,
                    reason="high_value_damage",
                    intent="damage_claim"
                )
                tool_calls_made.append("create_ticket()")
                session.ticket_created = t_res.get('created', False)
                session.ticket_id = t_res.get('ticket_id')
                reply = f"Under policy DWM-3, damage claims over ₹10,000 are handled by our Priority Resolution team. I have created a priority escalation ticket (Ticket: {session.ticket_id or 'created'}). Our specialist team will contact you shortly."
                session.history.append({'role': 'assistant', 'text': reply})
                return {'decision': decision, 'response': reply, 'spoken_response': SpeechNormalizer.normalize_for_tts(reply), 'tool_calls': tool_calls_made, 'evidence': gold_evidence, 'verified': True}

            if any(w in msg_lower for w in ['return', 'wapas', 'lautana', 'window']):
                decision = "answer"
                gold_evidence.extend(["RET-2", "RET-6"])
                delivery_dt = datetime.date.fromisoformat(delivery_date_str) if delivery_date_str else REFERENCE_DATE
                order_dt = datetime.date.fromisoformat(order_date_str) if order_date_str else REFERENCE_DATE
                is_festive = datetime.date(2026, 10, 1) <= order_dt <= datetime.date(2026, 10, 15)
                window_days = 30 if is_festive else 15
                if is_festive:
                    gold_evidence.append("RET-8")
                deadline_dt = delivery_dt + datetime.timedelta(days=window_days)
                fee_note = "ZentroMart Plus member hone ke kaaran reverse pickup free hai." if is_plus else "Reverse pickup fee of ₹49 applies."
                reply = f"Aap is order ko {deadline_dt.strftime('%d %B %Y')} ({deadline_dt.isoformat()}) tak return kar sakte hain. {fee_note}"
                session.history.append({'role': 'assistant', 'text': reply})
                return {'decision': decision, 'response': reply, 'spoken_response': SpeechNormalizer.normalize_for_tts(reply), 'tool_calls': tool_calls_made, 'evidence': gold_evidence, 'verified': True}

            if any(w in msg_lower for w in ['refund', 'paise', 'amount']):
                decision = "answer"
                gold_evidence.extend(["REF-2", "RET-7"])
                if is_plus:
                    gold_evidence.append("PLS-2")
                if 'wallet' in payment_method:
                    reply = "Wallet payments ka refund instant hota hai, initiate hone ke 2 ghante (2 hours) ke andar ZentroMart Wallet mein credit ho jaata hai."
                elif 'upi' in payment_method:
                    reply = "UPI refund initiate hone ke 1 se 3 business days ke andar bank account mein aa jaata hai."
                elif 'card' in payment_method:
                    reply = "Card payments ka refund 5 to 7 business days mein credit hota hai."
                else:
                    reply = "Refund 2 to 4 business days mein credit ho jaata hai."
                session.history.append({'role': 'assistant', 'text': reply})
                return {'decision': decision, 'response': reply, 'spoken_response': SpeechNormalizer.normalize_for_tts(reply), 'tool_calls': tool_calls_made, 'evidence': gold_evidence, 'verified': True}

        rag_res = RAGAgent(self.kb, self.retriever, self.llm).answer_question(message)
        session.history.append({'role': 'assistant', 'text': rag_res['response']})
        return {'decision': rag_res['decision'], 'response': rag_res['response'], 'spoken_response': SpeechNormalizer.normalize_for_tts(rag_res['response']), 'tool_calls': tool_calls_made, 'evidence': rag_res['retrieved_sections'], 'verified': session.verified}
