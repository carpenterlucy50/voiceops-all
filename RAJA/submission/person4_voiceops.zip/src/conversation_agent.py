"""Step 3 Structured Decision Conversation Agent for PERSON 4."""
import datetime
import re
from typing import Dict, Any, List, Optional
from .knowledge_base import KnowledgeBase, REFERENCE_DATE
from .retriever import PolicyAwareRetriever
from .tools_adapter import ToolsAdapter
from .llm_adapter import LLMAdapter
from .rag_agent import RAGAgent
from .state_machine import DialogStateMachine, DialogState, CustomerIntent, StructuredDecision


class ConversationAgent:
    def __init__(self, kb: KnowledgeBase, tools: ToolsAdapter, retriever: PolicyAwareRetriever = None, llm: LLMAdapter = None):
        self.kb = kb
        self.tools = tools
        self.retriever = retriever or PolicyAwareRetriever(kb)
        self.llm = llm or LLMAdapter()
        self.state_machines: Dict[str, DialogStateMachine] = {}

    def get_fsm(self, conv_id: str) -> DialogStateMachine:
        if conv_id not in self.state_machines:
            self.state_machines[conv_id] = DialogStateMachine(conv_id, max_retries=1)
        return self.state_machines[conv_id]

    def reset_session(self, conv_id: str):
        self.state_machines[conv_id] = DialogStateMachine(conv_id, max_retries=1)

    def process_turn(self, conv_id: str, message: str, explicit_order_id: Optional[str] = None) -> Dict[str, Any]:
        fsm = self.get_fsm(conv_id)
        fsm.history.append({'role': 'customer', 'text': message})
        intent: CustomerIntent = self.retriever.detect_intent(message)

        tool_calls_made = []
        gold_evidence = []
        decision = "answer"

        # Check order ID
        found_order_id = explicit_order_id or intent.entities.get('order_id')
        if not found_order_id:
            m_oid = re.search(r'\b(\d{4}\s*\d{4})\b', message) or re.search(r'\b(\d{8})\b', message)
            if m_oid:
                found_order_id = m_oid.group(1).replace(' ', '')

        if found_order_id and not fsm.order_id:
            fsm.transition("ORDER_ID_RECEIVED", {"order_id": found_order_id})

        # Turn 1: Initial state
        if fsm.state == DialogState.START and not fsm.order_id:
            decision = "clarify"
            gold_evidence.append("STY-1")
            reply = "Hello! I am ZentroMart's AI customer support assistant (एआई सहायक). How can I assist you today? Please share your 8-digit order number."
            fsm.history.append({'role': 'assistant', 'text': reply})
            return {'decision': decision, 'response': reply, 'tool_calls': tool_calls_made, 'evidence': gold_evidence, 'verified': False}

        # Awaiting verification: order known, proof needed
        if fsm.state == DialogState.AWAITING_VERIFICATION and fsm.verification_attempts == 0 and not fsm.verified_order_data:
            # Check if customer already supplied phone last4 or pincode in this message
            m_proof = re.search(r'\b(\d{4})\b', message) or re.search(r'\b(\d{6})\b', message)
            if not m_proof or m_proof.group(1) == fsm.order_id[-4:]:
                tool_calls_made.append(f"lookup_order(order_id={fsm.order_id})")
                self.tools.lookup(fsm.order_id)
                decision = "clarify"
                gold_evidence.append("IDV-2")
                reply = f"Thank you for sharing order {fsm.order_id}. To verify your identity, please provide the last 4 digits of your registered phone number or your 6-digit delivery pincode (आख़िरी चार अंक या पिनकोड)."
                fsm.history.append({'role': 'assistant', 'text': reply})
                return {'decision': decision, 'response': reply, 'tool_calls': tool_calls_made, 'evidence': gold_evidence, 'verified': False}

        # Verification proof submitted
        if fsm.state == DialogState.AWAITING_VERIFICATION:
            m_proof = re.search(r'\b(\d{4})\b', message) or re.search(r'\b(\d{6})\b', message)
            if m_proof:
                proof = m_proof.group(1)
                tool_calls_made.append(f"lookup_order(order_id={fsm.order_id}, verification_value={proof})")
                res = self.tools.lookup(fsm.order_id, verification_value=proof)

                if res.get('verified'):
                    fsm.transition("VERIFICATION_SUCCESS", {"order_data": res})
                    decision = "answer"
                    gold_evidence.append("IDV-2")
                    name = res.get('customer_first_name', 'Customer')
                    reply = f"Thank you, {name}! Your identity is verified. How can I assist you with order {fsm.order_id}?"
                    fsm.history.append({'role': 'assistant', 'text': reply})
                    return {'decision': decision, 'response': reply, 'tool_calls': tool_calls_made, 'evidence': gold_evidence, 'verified': True}
                else:
                    fsm.transition("VERIFICATION_FAILED")
                    gold_evidence.append("IDV-3")
                    if fsm.state == DialogState.VERIFICATION_FAILED_LOCKED:
                        decision = "refuse"
                        reply = "Verification failed after two attempts. To protect your account, I cannot share order details. Please contact customer care from your registered phone."
                    else:
                        decision = "clarify"
                        reply = "The verification details did not match. Please re-check and share the last 4 digits of your phone or delivery pincode."
                    fsm.history.append({'role': 'assistant', 'text': reply})
                    return {'decision': decision, 'response': reply, 'tool_calls': tool_calls_made, 'evidence': gold_evidence, 'verified': False}

        # Verified State
        if fsm.state == DialogState.VERIFIED and fsm.verified_order_data:
            order = fsm.verified_order_data
            items = order.get('items', [])
            is_plus = order.get('is_plus', False)
            total_inr = order.get('total_inr', 0)
            delivery_date_str = order.get('delivery_date')
            order_date_str = order.get('order_date')
            payment_method = str(order.get('payment_method', '')).lower()
            msg_lower = message.lower()

            is_damage = any(w in msg_lower for w in ['damage', 'defect', 'damaged', 'broken', 'kharab'])
            is_high_val = total_inr > 10000 or any(it.get('price_inr', 0) > 10000 for it in items)

            if is_damage and is_high_val:
                decision = "escalate"
                gold_evidence.extend(["DWM-3", "ESC-1", "ESC-4"])
                t_res = self.tools.ticket(
                    summary=f"Damage report on order {fsm.order_id} exceeding ₹10,000 threshold. Escalated to Priority Resolution team.",
                    order_id=fsm.order_id,
                    reason="high_value_damage",
                    intent="damage_claim"
                )
                tool_calls_made.append("create_ticket()")
                fsm.transition("ESCALATE_TICKET", {"ticket_id": t_res.get('ticket_id')})
                reply = f"Per Damaged Items Policy (DWM-3), damage claims exceeding ₹10,000 are handled directly by our Priority Resolution team. I have created a priority escalation ticket (Ticket: {fsm.ticket_id or 'created'}). Our specialist team will review your photos and follow up promptly."
                fsm.history.append({'role': 'assistant', 'text': reply})
                return {'decision': decision, 'response': reply, 'tool_calls': tool_calls_made, 'evidence': gold_evidence, 'verified': True}

            if any(w in msg_lower for w in ['return', 'wapas', 'lautana', 'window']):
                decision = "answer"
                gold_evidence.extend(["RET-2", "RET-6"])
                delivery_dt = datetime.date.fromisoformat(delivery_date_str) if delivery_date_str else REFERENCE_DATE
                order_dt = datetime.date.fromisoformat(order_date_str) if order_date_str else REFERENCE_DATE
                is_festive = datetime.date(2026, 10, 1) <= order_dt <= datetime.date(2026, 10, 15)
                window_days = 30 if is_festive else 15
                if is_festive:
                    gold_evidence.append("RET-8")
                deadline_dt = delivery_dt + datetime.timedelta(days=window_days)
                fee_note = "ZentroMart Plus member hone ke kaaran reverse pickup free hai." if is_plus else "Reverse pickup fee of ₹49 applies."
                reply = f"Aap is order ko {deadline_dt.strftime('%d %B %Y')} ({deadline_dt.isoformat()}) tak return kar sakte hain. {fee_note}"
                fsm.history.append({'role': 'assistant', 'text': reply})
                return {'decision': decision, 'response': reply, 'tool_calls': tool_calls_made, 'evidence': gold_evidence, 'verified': True}

            if any(w in msg_lower for w in ['refund', 'paise', 'amount']):
                decision = "answer"
                gold_evidence.extend(["REF-2", "RET-7"])
                if is_plus:
                    gold_evidence.append("PLS-2")
                if 'wallet' in payment_method:
                    reply = "Wallet payments ka refund instant hota hai, initiate hone ke 2 ghante (2 hours) ke andar ZentroMart Wallet mein credit ho jaata hai."
                elif 'upi' in payment_method:
                    reply = "UPI refund initiate hone ke 1 se 3 business days ke andar bank account mein aa jaata hai."
                elif 'card' in payment_method:
                    reply = "Card payments ka refund 5 to 7 business days mein credit hota hai."
                else:
                    reply = "Refund 2 to 4 business days mein credit ho jaata hai."
                fsm.history.append({'role': 'assistant', 'text': reply})
                return {'decision': decision, 'response': reply, 'tool_calls': tool_calls_made, 'evidence': gold_evidence, 'verified': True}

        rag_res = RAGAgent(self.kb, self.retriever, self.llm).answer_question(message)
        fsm.history.append({'role': 'assistant', 'text': rag_res['response']})
        return {'decision': rag_res['decision'], 'response': rag_res['response'], 'tool_calls': tool_calls_made, 'evidence': rag_res['retrieved_sections'], 'verified': (fsm.state == DialogState.VERIFIED)}
