"""Step 1: Prompt-Only LLM Baseline (No Document Retrieval).

Evaluates the assistant without knowledge base retrieval to establish an empirical baseline.
"""
from typing import Dict, Any, List
from .llm_adapter import LLMAdapter

BASELINE_SYSTEM_PROMPT = """You are an AI customer support assistant for ZentroMart, an Indian online shopping store.
Always identify yourself as an AI assistant.
Answer customer questions to the best of your general knowledge.
Do not refer to specific internal documents since you have not been provided with the knowledge base yet.
Be polite and helpful.
"""


class BaselineAgent:
    def __init__(self, llm: LLMAdapter = None):
        self.llm = llm or LLMAdapter()

    def answer_question(self, question: str) -> Dict[str, Any]:
        """Answer question without any document retrieval."""
        response, source = self.llm.generate(
            prompt=question,
            system_prompt=BASELINE_SYSTEM_PROMPT,
            context=None
        )
        return {
            'question': question,
            'response': response,
            'retrieved_sections': [],
            'source': source,
            'has_retrieval': False
        }
