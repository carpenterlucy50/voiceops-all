"""
PERSON 6 — Step 3: Conversational Agent with Adaptive RAG, Tool Execution, and Error Categorization Tracing
"""

import re
import datetime
from typing import Dict, Any, List, Optional
from .retriever import AdaptiveRetriever
from .tools_adapter import ToolsAdapter, REFERENCE_DATE
from .llm_adapter import LLMAdapter

class ConvSession:
    def __init__(self, conv_id: str):
        self.conv_id = conv_id
        self.order_id: Optional[str] = None
        self.verified: bool = False
        self.verification_pending: bool = False
        self.verification_attempts: int = 0
        self.order_data: Optional[Dict[str, Any]] = None
        self.escalated: bool = False
        self.ticket_id: Optional[str] = None
        self.ticket_created: bool = False
        self.history: List[Dict[str, str]] = []

class ConversationAgent:
    def __init__(self, retriever: AdaptiveRetriever, tools_adapter: ToolsAdapter, llm: LLMAdapter):
        self.retriever = retriever
        self.tools = tools_adapter
        self.llm = llm
        self.sessions: Dict[str, ConvSession] = {}
        self.default_session_id = "default"
        self.traces: List[Dict[str, Any]] = []

    def get_session(self, conv_id: Optional[str] = None) -> ConvSession:
        cid = conv_id or self.default_session_id
        if cid not in self.sessions:
            self.sessions[cid] = ConvSession(cid)
        return self.sessions[cid]

    def reset(self, conv_id: Optional[str] = None):
        cid = conv_id or self.default_session_id
        self.sessions[cid] = ConvSession(cid)

    def reset_session(self, conv_id: str):
        self.sessions[conv_id] = ConvSession(conv_id)

    def process_turn(self, arg1: str, arg2: Optional[str] = None, explicit_order_id: Optional[str] = None) -> Dict[str, Any]:
        if arg2 is not None:
            conv_id = arg1
            message = arg2
        else:
            conv_id = self.default_session_id
            message = arg1

        session = self.get_session(conv_id)
        session.history.append({"role": "customer", "text": message})
        msg_clean = message.strip()
        msg_lower = msg_clean.lower()

        tool_calls_made = []
        gold_evidence = []
        decision = "answer"
        trace_record = {
            "conv_id": conv_id,
            "turn_index": len(session.history),
            "user_input": message,
            "tool_call": None,
            "decision": None,
            "error_category": None
        }

        # Order ID detection
        found_order_id = explicit_order_id
        if not found_order_id:
            m_oid = re.search(r"\b(\d{4}\s*\d{4})\b", msg_clean) or re.search(r"\b(\d{8})\b", msg_clean)
            if m_oid:
                found_order_id = m_oid.group(1).replace(" ", "")

        if found_order_id and not session.order_id:
            session.order_id = found_order_id

        # Turn 1: No order ID provided yet
        if not session.order_id and not session.verified:
            decision = "clarify"
            gold_evidence.append("STY-1")
            reply = (
                "Hello! I am ZentroMart's AI customer support assistant (एआई सहायक). "
                "I would be glad to help you today. Could you please share your 8-digit order number?"
            )
            session.history.append({"role": "assistant", "text": reply})
            trace_record["decision"] = decision
            return self._format_result(session, reply, decision, tool_calls_made, gold_evidence, trace_record)

        # Verification Step 1: Order ID present, request verification details
        if session.order_id and not session.verified and not session.verification_pending:
            session.verification_pending = True
            tool_calls_made.append(f"lookup_order(order_id={session.order_id})")
            self.tools.lookup(session.order_id)
            decision = "clarify"
            gold_evidence.append("IDV-2")
            reply = (
                f"Thank you for providing order {session.order_id}. To protect your privacy, "
                "could you please verify your identity by sharing the last 4 digits of your registered phone number "
                "or your 6-digit delivery pincode (आख़िरी चार अंक या पिनकोड)?"
            )
            session.history.append({"role": "assistant", "text": reply})
            trace_record["tool_call"] = f"lookup_order({session.order_id})"
            trace_record["decision"] = decision
            return self._format_result(session, reply, decision, tool_calls_made, gold_evidence, trace_record)

        # Verification Step 2: Customer provided verification input
        if session.order_id and not session.verified and session.verification_pending:
            m_proof = re.search(r"\b(\d{4})\b", msg_clean) or re.search(r"\b(\d{6})\b", msg_clean)
            if m_proof:
                proof = m_proof.group(1)
                session.verification_attempts += 1
                tool_calls_made.append(f"lookup_order(order_id={session.order_id}, verification_value={proof})")
                res = self.tools.lookup(session.order_id, verification_value=proof)

                if res.get("verified"):
                    session.verified = True
                    session.verification_pending = False
                    session.order_data = res
                    decision = "answer"
                    gold_evidence.append("IDV-2")
                    first_name = res.get("customer_first_name", "Customer")
                    reply = (
                        f"Thank you, {first_name}! Your identity has been verified. "
                        f"How can I assist you with order {session.order_id} today?"
                    )
                    session.history.append({"role": "assistant", "text": reply})
                    trace_record["decision"] = decision
                    return self._format_result(session, reply, decision, tool_calls_made, gold_evidence, trace_record)
                else:
                    gold_evidence.append("IDV-3")
                    if session.verification_attempts < 2:
                        decision = "clarify"
                        trace_record["error_category"] = "VERIFICATION_RETRY"
                        reply = (
                            "The verification details you provided did not match our records. "
                            "Please re-check and share the last 4 digits of your phone number or your delivery pincode."
                        )
                    else:
                        decision = "refuse"
                        trace_record["error_category"] = "VERIFICATION_FAILED"
                        reply = (
                            "I'm sorry, but identity verification has failed after two attempts. "
                            "To keep your account secure, I cannot share order details. Please contact support from your registered phone."
                        )
                    session.history.append({"role": "assistant", "text": reply})
                    trace_record["decision"] = decision
                    return self._format_result(session, reply, decision, tool_calls_made, gold_evidence, trace_record)

        # Verified queries
        if session.verified and session.order_data:
            order = session.order_data
            items = order.get("items", [])
            is_plus = order.get("is_plus", False)
            total_inr = order.get("total_inr", 0)
            delivery_date_str = order.get("delivery_date")
            order_date_str = order.get("order_date")

            # Escalation on High Value Damage (> 10,000)
            is_damage = any(w in msg_lower for w in ["damage", "defect", "damaged", "kharab", "broken", "torn"])
            is_high_value = total_inr > 10000 or any(it.get("price_inr", 0) > 10000 for it in items)

            if is_damage and is_high_value:
                decision = "escalate"
                gold_evidence.extend(["DWM-3", "ESC-1", "ESC-4"])
                t_res = self.tools.ticket(
                    summary=f"Verified customer reports damaged high-value order {session.order_id} (value > ₹10,000). Priority review required.",
                    order_id=session.order_id,
                    reason="high_value_damage",
                    intent="damage_claim"
                )
                tool_calls_made.append("create_ticket()")
                session.ticket_created = t_res.get("created", False)
                session.ticket_id = t_res.get("ticket_id")
                trace_record["error_category"] = "HIGH_VALUE_ESCALATION"

                reply = (
                    "Under ZentroMart's Damaged Items Policy (DWM-3), damage claims on items over ₹10,000 "
                    f"are handled directly by our Priority Resolution team. I have logged a priority ticket for you "
                    f"(Ticket ID: {session.ticket_id or 'created'}). Our specialist team will review your photos and contact you promptly."
                )
                session.history.append({"role": "assistant", "text": reply})
                trace_record["decision"] = decision
                return self._format_result(session, reply, decision, tool_calls_made, gold_evidence, trace_record)

            # Return eligibility calculation
            if any(w in msg_lower for w in ["return", "wapas", "lautana", "window"]):
                decision = "answer"
                gold_evidence.extend(["RET-2", "RET-6"])
                delivery_dt = datetime.date.fromisoformat(delivery_date_str) if delivery_date_str else REFERENCE_DATE
                order_dt = datetime.date.fromisoformat(order_date_str) if order_date_str else REFERENCE_DATE

                is_festive = datetime.date(2026, 10, 1) <= order_dt <= datetime.date(2026, 10, 15)
                window_days = 30 if is_festive else 15
                if is_festive:
                    gold_evidence.append("RET-8")

                deadline_dt = delivery_dt + datetime.timedelta(days=window_days)
                deadline_str = deadline_dt.strftime("%d %B %Y")
                deadline_iso = deadline_dt.isoformat()
                pickup_note = "ZentroMart Plus member hone ke kaaran reverse pickup bilkul free hai." if is_plus else "Reverse pickup fee of ₹49 applies."

                reply = (
                    f"Haan, aap is order ko delivery date se {window_days} din ke andar yani {deadline_str} ({deadline_iso}) tak wapas kar sakte hain. "
                    f"{pickup_note} Kya aap chahte hain ki main return request initiate kar doon?"
                )
                session.history.append({"role": "assistant", "text": reply})
                trace_record["decision"] = decision
                return self._format_result(session, reply, decision, tool_calls_made, gold_evidence, trace_record)

            # Order Status / Delivery queries
            if any(w in msg_lower for w in ["status", "kahan hai", "track", "delivery", "kab tak"]):
                decision = "answer"
                status = order.get("status", "Delivered")
                gold_evidence.append("ORD-1")
                reply = f"Aapka order {session.order_id} abhi '{status}' status mein hai. Total amount: ₹{total_inr}."
                session.history.append({"role": "assistant", "text": reply})
                trace_record["decision"] = decision
                return self._format_result(session, reply, decision, tool_calls_made, gold_evidence, trace_record)

        # General Policy / RAG Query
        chunks, r_trace = self.retriever.retrieve(msg_clean)
        trace_record["retrieval_trace"] = r_trace.to_dict()

        if r_trace.abstained:
            decision = "abstain"
            trace_record["error_category"] = "UNSUPPORTED_OR_OUT_OF_DOMAIN"
            reply = "I am ZentroMart's AI assistant. Our official documentation does not contain support or policy guidelines for this query. I must respectfully decline to provide an unverified response."
        else:
            decision = "answer"
            context_str = "\n\n".join([f"[{c.section}] {c.title}\n{c.content}" for c in chunks])
            rag_prompt = f"RETRIEVED CONTEXT:\n{context_str}\n\nCUSTOMER QUESTION: {msg_clean}\n\nAnswer concisely according to ZentroMart policies:"
            reply = self.llm.generate(prompt=rag_prompt)
            for c in chunks:
                gold_evidence.append(c.section)

        session.history.append({"role": "assistant", "text": reply})
        trace_record["decision"] = decision
        return self._format_result(session, reply, decision, tool_calls_made, gold_evidence, trace_record)

    def _format_result(self, session: ConvSession, reply: str, decision: str, tool_calls: List[str], evidence: List[str], trace: Dict[str, Any]) -> Dict[str, Any]:
        self.traces.append(trace)
        return {
            "response": reply,
            "decision": decision,
            "tool_calls": tool_calls,
            "evidence": evidence,
            "order_id": session.order_id,
            "verified": session.verified,
            "ticket_id": session.ticket_id,
            "escalated": session.escalated,
            "trace": trace
        }
