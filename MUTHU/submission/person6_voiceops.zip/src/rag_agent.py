"""
PERSON 6 — Step 2: Evaluation-Driven Adaptive RAG Agent
"""

from typing import Dict, Any, Optional
from .retriever import AdaptiveRetriever, RetrievalTrace
from .llm_adapter import LLMAdapter

RAG_SYSTEM_PROMPT = """You are ZentroMart's authoritative AI Customer Support Agent.
Always identify yourself as an AI assistant.
Answer customer questions STRICTLY using the retrieved context from ZentroMart internal documentation.
Follow official policy precedence: Policy (RET, REF) overrides Guides, Help, FAQs, and Marketing.
Current policies override superseded policies unless the customer explicitly references older orders prior to 1 August 2026.
If the retrieved evidence does not contain sufficient facts to answer the question, or if you are instructed to abstain, state clearly and politely that ZentroMart documentation does not support the request."""

class AdaptiveRAGAgent:
    def __init__(self, retriever: AdaptiveRetriever, llm: LLMAdapter):
        self.retriever = retriever
        self.llm = llm

    def answer_question(self, question: str, strategy: Optional[str] = None, top_k: Optional[int] = None) -> Dict[str, Any]:
        chunks, trace = self.retriever.retrieve(question, strategy=strategy, top_k=top_k)
        
        if trace.abstained:
            abstention_resp = f"I am ZentroMart's AI assistant. Our official documentation does not contain support or policy guidelines for this query ({trace.abstention_reason}). I must respectfully abstain from providing an unsupported answer."
            return {
                "question": question,
                "response": abstention_resp,
                "is_rag": True,
                "grounded": False,
                "abstained": True,
                "trace": trace.to_dict(),
                "retrieved_evidence": []
            }

        context_str = "\n\n".join([f"Source: {c.title} ({c.doc_id} - Section {c.section})\n{c.content}" for c in chunks])
        prompt = f"RETRIEVED EVIDENCE:\n{context_str}\n\nCUSTOMER QUESTION: {question}\n\nAnswer based strictly on the retrieved evidence:"
        response_text = self.llm.generate(prompt=prompt, system_prompt=RAG_SYSTEM_PROMPT)

        evidence_records = [
            {
                "doc_id": c.doc_id,
                "section": c.section,
                "title": c.title,
                "authority": c.authority_level,
                "status": c.status
            }
            for c in chunks
        ]

        return {
            "question": question,
            "response": response_text,
            "is_rag": True,
            "grounded": True,
            "abstained": False,
            "trace": trace.to_dict(),
            "retrieved_evidence": evidence_records
        }
