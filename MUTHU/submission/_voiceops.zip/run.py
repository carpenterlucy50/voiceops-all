#!/usr/bin/env python3
"""
PERSON 6 — Evaluation-Driven Adaptive RAG Support Agent
Command Line Interface and Multi-Mode Runner
"""

import os
import sys
import argparse

cur_dir = os.path.dirname(os.path.abspath(__file__))
if cur_dir not in sys.path:
    sys.path.insert(0, cur_dir)

from src.knowledge_base import KnowledgeBase
from src.retriever import AdaptiveRetriever
from src.tools_adapter import ToolsAdapter
from src.llm_adapter import LLMAdapter
from src.baseline import BaselineAgent
from src.rag_agent import AdaptiveRAGAgent
from src.conversation_agent import ConversationAgent
from src.voice_adapter import GnaniVoiceAdapter
from src.benchmark_suite import BenchmarkSuite
from evaluation.eval_questions import run_evaluation as eval_q
from evaluation.eval_conversations import run_evaluation as eval_c
from src.cli import run_interactive_cli, run_voice_cli

def main():
    parser = argparse.ArgumentParser(description="PERSON 6: Evaluation-Driven Adaptive RAG Agent")
    parser.add_argument("--mode", choices=["chat", "voice", "evaluate", "benchmark", "batch"], default="chat", help="Execution mode")
    parser.add_argument("--strategy", choices=["lexical", "dense", "hybrid", "adaptive"], default="adaptive", help="Retrieval strategy")
    parser.add_argument("--voice", action="store_true", default=False, help="Speak aloud")
    parser.add_argument("--top-k", type=int, default=5, help="Top-K chunks to retrieve")
    parser.add_argument("--dataset-dir", default=os.path.join(cur_dir, "Capstone_Project_Dataset_FTTT_2026"), help="Dataset directory")
    parser.add_argument("--output-dir", default=os.path.join(cur_dir, "sample_outputs"), help="Output directory")
    parser.add_argument("--input-dir", help="Directory containing audio files for batch processing")
    parser.add_argument("--query", help="Single query to test adaptive retrieval and print execution trace")

    args = parser.parse_args()

    # If --input-dir is passed without --mode batch, automatically switch to batch mode
    if args.input_dir:
        args.mode = "batch"

    kb = KnowledgeBase(args.dataset_dir)
    retriever = AdaptiveRetriever(kb, default_strategy=args.strategy, default_top_k=args.top_k)
    tools = ToolsAdapter(args.dataset_dir)
    llm = LLMAdapter(provider="auto")
    agent = ConversationAgent(retriever, tools, llm)
    voice_adapter = GnaniVoiceAdapter(agent)

    if args.query:
        print(f"\n[Adaptive Query] '{args.query}' (Strategy: {args.strategy}, Top-K: {args.top_k})")
        rag = AdaptiveRAGAgent(retriever, llm)
        res = rag.answer_question(args.query, strategy=args.strategy, top_k=args.top_k)
        print(f"\nResponse: {res['response']}")
        print(f"\nTrace: {res['trace']}")
        print(f"Evidence: {res['retrieved_evidence']}")
        return

    if args.mode == "benchmark":
        print("\n=== Running Adaptive RAG Grid Benchmark Suite ===")
        suite = BenchmarkSuite(args.dataset_dir, args.output_dir)
        results = suite.run_grid_experiment()
        print(f"Benchmark finished! Output dashboard: {os.path.join(args.output_dir, 'benchmark_dashboard.html')}")
        print(f"Summary JSON: {os.path.join(args.output_dir, 'benchmark_summary.json')}")

    elif args.mode == "evaluate":
        print("\n=== Running Step 1 vs Step 2 Questions Evaluation ===")
        q_metrics = eval_q(args.dataset_dir, args.output_dir)
        print(f"Questions Metrics: {q_metrics}")

        print("\n=== Running Step 3 Multi-Turn Conversations Evaluation ===")
        c_metrics = eval_c(args.dataset_dir, args.output_dir)
        print(f"Conversations Metrics: {c_metrics}")

    elif args.mode == "batch":
        if not args.input_dir:
            print("Error: --input-dir required for batch mode.")
            sys.exit(1)
        print(f"\n=== Processing Batch Audio with Gnani.ai from '{args.input_dir}' ===")
        if not voice_adapter.is_live:
            print("\n[BLOCKED] Gnani credentials not configured: GNANI_API_KEY environment variable is missing.")
            print("  Please configure GNANI_API_KEY in your .env file or environment.")
            summary = voice_adapter.process_batch(args.input_dir, args.output_dir)
            sys.exit(1)
        summary = voice_adapter.process_batch(args.input_dir, args.output_dir)
        print(f"Batch completed: {summary['successful']}/{summary['total_files']} successful.")
        sys.exit(0 if summary["failed"] == 0 else 1)

    elif args.mode == "voice":
        run_voice_cli(agent, voice_adapter=voice_adapter)
    elif args.mode == "chat":
        run_interactive_cli(agent, voice_adapter=voice_adapter if args.voice else None)
        print("\n" + "="*60)
        print("  ZentroMart Support Agent — Person 6 (Adaptive RAG)")
        print(f"  Strategy: {args.strategy} | Top-K: {args.top_k} | LLM: {llm.provider}")
        print("  Type 'exit' to quit, 'reset' to clear session, 'trace' for last query trace.")
        print("="*60 + "\n")

        while True:
            try:
                user_msg = input("\nCustomer > ").strip()
                if not user_msg:
                    continue
                if user_msg.lower() in ["exit", "quit"]:
                    break
                if user_msg.lower() == "reset":
                    agent.reset()
                    print("[Session reset]")
                    continue
                if user_msg.lower() == "trace":
                    print(f"Last Trace: {retriever.last_trace.to_dict() if retriever.last_trace else 'No trace available'}")
                    continue

                res = agent.process_turn(user_msg)
                print(f"\nAssistant > {res['response']}")
                if res.get("trace", {}).get("tool_call"):
                    print(f"  [Tool Executed]: {res['trace']['tool_call']} -> {res['trace']['tool_result']}")
            except (KeyboardInterrupt, EOFError):
                break

if __name__ == "__main__":
    main()
